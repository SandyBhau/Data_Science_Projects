import{b2 as o}from"./vendor-47656783.js";function e(){return o.jsx("h1",{children:"404"})}e.displayName="NoPage";export{e as Component};
//# sourceMappingURL=NoPage-6b623514.js.map
